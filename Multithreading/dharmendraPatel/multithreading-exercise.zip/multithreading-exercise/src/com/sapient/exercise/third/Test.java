package com.sapient.exercise.third;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class Test {

	public static void main(String[] args) {
		List<Integer> queue = new ArrayList<Integer>();
		Producer producer = new Producer(queue);
		Consumer consumer = new Consumer(queue);
		
		Executor executor = Executors.newFixedThreadPool(2);
		
		executor.execute(producer);
		executor.execute(consumer);

	}
}
