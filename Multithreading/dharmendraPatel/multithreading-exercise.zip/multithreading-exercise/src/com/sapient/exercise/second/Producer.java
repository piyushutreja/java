package com.sapient.exercise.second;


public class Producer implements Runnable {

	private BlockingQueue<Integer> queue;
	
	public Producer(BlockingQueue<Integer> queue){
		this.queue=queue;
	}
	
	@Override
	public void run() {
		while(true){
			try {
				System.out.println("Took: " + queue.take()+" current size of queue is: "+queue.size());
				Thread.sleep(10);
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}
		}
	}
}
