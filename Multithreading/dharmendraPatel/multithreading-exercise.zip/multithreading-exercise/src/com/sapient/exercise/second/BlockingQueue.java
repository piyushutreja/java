package com.sapient.exercise.second;

import java.util.LinkedList;
import java.util.List;

public class BlockingQueue<T> {

	private List<T> queue = new LinkedList<T>();
	private int limit = 10;

	public BlockingQueue(int limit) {
		this.limit = limit;
	}

	public synchronized void put(T item) throws InterruptedException {
		while (this.queue.size() == this.limit) {
			wait();
		}
		this.queue.add(item);
		notifyAll();
	}

	public synchronized T take() throws InterruptedException {
		while (this.queue.size() == 0) {
			wait();
		}
		T t = this.queue.remove(0);
		notifyAll();
		return t;
	}
	
	public synchronized int size(){
		return this.queue.size();
	}
}