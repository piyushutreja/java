package com.sapient.exercise.first;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/*
 * Producer consumer implementation using blocking queue
 */
public class Test {

	public static void main(String[] args) {
		BlockingQueue<Integer> queue = new ArrayBlockingQueue<Integer>(10);
		Producer producer = new Producer(queue);
		Consumer consumer = new Consumer(queue);
		
		Executor executor = Executors.newFixedThreadPool(2);
		
		executor.execute(producer);
		executor.execute(consumer);

	}
}
