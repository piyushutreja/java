package com.sapient.exercise.third;

import java.util.List;
import java.util.Random;

public class Producer implements Runnable{

	private List<Integer> list;
	
	public Producer(List<Integer> list){
		this.list=list;
	}
	
	@Override
	public void run() {
		Random random = new Random();
		while (true) {
			synchronized (list) {

				try {
					while(list.size() == 10) {
						list.wait();
					}
					int next = random.nextInt();
					System.out.println("Put : " + next + " size : "+list.size());
					list.add(next);
					Thread.sleep(10);
					list.notifyAll();
				} catch (InterruptedException e) {
					System.out.println(e.getMessage());
				}
			}
		}
	}

}
