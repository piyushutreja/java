package com.sapient.exercise.third;

import java.util.List;

public class Consumer implements Runnable{

private List<Integer> list;
	
	public Consumer(List list){
		this.list=list;
	}
	
	@Override
	public void run() {
		while (true) {
			synchronized (list) {
				try {
					while(list.isEmpty()) {
						list.wait();
					}
					System.out.println("Took : " + list.remove(0) + " size : "+list.size());
					Thread.sleep(1000);
					list.notifyAll();
				} catch (InterruptedException e) {
					System.out.println(e.getMessage());
				}
			}
		}
	}

}
