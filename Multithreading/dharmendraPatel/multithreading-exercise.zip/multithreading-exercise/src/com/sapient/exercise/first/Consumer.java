package com.sapient.exercise.first;
import java.util.Random;
import java.util.concurrent.BlockingQueue;


public class Consumer implements Runnable {

	private BlockingQueue<Integer> queue;
	
	public Consumer(BlockingQueue<Integer> queue){
		this.queue=queue;
	}
	
	@Override
	public void run() {
		Random random = new Random();
		
		while(true){
			try {
				int next = random.nextInt();
				System.out.println("put: " + next +" current size of queue is: "+queue.size());
				queue.put(next);
				Thread.sleep(100);
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}
		}
	}
}

