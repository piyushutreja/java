package com.sapient.exercise.second;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/*
 * Producer consumer implementation using own blocking queue implementation
 */
public class Test {

	public static void main(String[] args) {
		BlockingQueue<Integer> queue = new BlockingQueue<Integer>(10);
		Producer producer = new Producer(queue);
		Consumer consumer = new Consumer(queue);
		
		Executor executor = Executors.newFixedThreadPool(2);
		
		executor.execute(producer);
		executor.execute(consumer);

	}
}
