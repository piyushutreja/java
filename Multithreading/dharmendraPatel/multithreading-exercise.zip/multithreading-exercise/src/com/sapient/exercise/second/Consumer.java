package com.sapient.exercise.second;
import java.util.Random;


public class Consumer implements Runnable {

	private BlockingQueue<Integer> queue;
	
	public Consumer(BlockingQueue<Integer> queue){
		this.queue=queue;
	}
	
	@Override
	public void run() {
		Random random = new Random();
		
		while(true){
			try {
				int next = random.nextInt();
				System.out.println("put: " + next +" current size of queue is: "+queue.size());
				queue.put(next);
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}
		}
	}
}

