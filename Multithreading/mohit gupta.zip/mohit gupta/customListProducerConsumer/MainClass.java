package com.practise.customListProducerConsumer;


public class MainClass {

	private static MyArrayList storage=null;
	private static int size;
	
	public MainClass() {
		
	}
	
	public static void main(String[] args) {
		size=10;
		storage = new MyArrayList();
		System.out.println("Starting consumer producer threads...");
		ConsumerImpl consumer = new ConsumerImpl(storage, size);
		ProducerImpl producer = new ProducerImpl(storage, size);
	
		producer.start();
		consumer.start();
	}
	
	
}
