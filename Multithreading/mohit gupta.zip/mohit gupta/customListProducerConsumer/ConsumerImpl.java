package com.practise.customListProducerConsumer;


public class ConsumerImpl extends Thread{

	private MyArrayList storage=null;
	
	public ConsumerImpl(MyArrayList storage,int size) {
		
		this.storage = storage;
	}
	
	@Override
	public void run() {

		
		while(true){
		synchronized (storage) {
			if(storage.size()==0){
				
				try {
					System.out.println("consumer waiting...........");
					storage.notify();
					storage.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			try {
				System.out.println("Consumer Resumed........");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Integer token = storage.remove(0);
			System.out.println("Consumed="+token);

		}
		
		}
	
	}
}
