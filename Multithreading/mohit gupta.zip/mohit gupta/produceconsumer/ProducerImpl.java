package com.practise.produceconsumer;

import java.util.Queue;

public class ProducerImpl extends Thread{
	
	private Queue<String> storage=null;
	private int size;
	private static int counter=0;
	public ProducerImpl(Queue<String> storage,int size) {
		this.size=size;
		this.storage = storage;
	}
	
	@Override
	public void run() {
	
		while(true){
		synchronized (storage) {
			if(storage.size()>=size){
				try {
					System.out.println("Producer waiting...........");
					storage.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			try {
				System.out.println("Producer Resumed........");
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Produced Token="+counter);
			storage.add("Token"+counter);
			counter=counter+1;
			storage.notifyAll();
		}
		}	
		
	}
}
