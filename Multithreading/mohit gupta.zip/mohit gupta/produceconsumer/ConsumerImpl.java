package com.practise.produceconsumer;

import java.util.Queue;

public class ConsumerImpl extends Thread{

	private Queue<String> storage=null;
	
	public ConsumerImpl(Queue<String> storage,int size) {
		
		this.storage = storage;
	}
	
	@Override
	public void run() {

		
		while(true){
		synchronized (storage) {
			if(storage.isEmpty()){
				
				try {
					System.out.println("consumer waiting...........");
					storage.notify();
					storage.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			try {
				System.out.println("Consumer Resumed........");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String token = storage.poll();
			System.out.println("Consumed="+token);

		}
		
		}
	
	}
}
