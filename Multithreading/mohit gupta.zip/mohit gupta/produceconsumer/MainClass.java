package com.practise.produceconsumer;

import java.util.LinkedList;
import java.util.Queue;

public class MainClass {

	private static Queue<String> storage=null;
	private static int size;
	
	public MainClass() {
		
	}
	
	public static void main(String[] args) {
		size=1;
		storage = new LinkedList<String>();
		System.out.println("Starting consumer producer threads...");
		ConsumerImpl consumer = new ConsumerImpl(storage, size);
		ProducerImpl producer = new ProducerImpl(storage, size);
	
		producer.start();
		consumer.start();
	}
	
	
}
