package com.practise.bockingqueue;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

public class ProducerBlockingQueue implements Runnable{

	private BlockingQueue< Integer> queue;
	private volatile int counter =0;
	
	public ProducerBlockingQueue(BlockingQueue<Integer> queue) {
	this.queue=queue;
	}
	@Override
	public void run() {
	while(true){
		try {
			queue.put(counter++);
			System.out.println("Produced==>"+counter);
			TimeUnit.MILLISECONDS.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}}
