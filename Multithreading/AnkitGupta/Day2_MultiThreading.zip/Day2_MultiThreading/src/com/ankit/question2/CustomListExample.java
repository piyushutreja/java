package com.ankit.question2;

public class CustomListExample {

	public static void main(String[] args) throws InterruptedException {
		CustomList queue = new CustomList(10);
		Thread t1 = new Thread(new Producer(queue));
		Thread t2 = new Thread(new Consumer(queue));

		t1.start();
		t2.start();

	}
}

class Consumer implements Runnable {
	CustomList queue = null;

	public Consumer(CustomList queue) {
		this.queue = queue;
	}

	@Override
	public void run() {
		while (true) {
			System.out.println("Consumer : " + queue.get());
		}

	}
}

class Producer implements Runnable {
	CustomList queue = null;

	public Producer(CustomList queue) {
		this.queue = queue;
	}

	@Override
	public void run() {
		for (int i = 0;; i++) {
			queue.put(i);
			System.out.println("Produce :" + i);
		}

	}
}