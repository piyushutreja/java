package com.ankit.question2;

public class CustomList {
	Integer[] array;
	Integer pointer;

	public CustomList(int size) {
		array = new Integer[size];
		pointer = 0;
	}

	public int get() {
		int value = 0;
		synchronized (array) {
			while (pointer == 0) {
				try {
					array.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			value = array[--pointer];
			array.notify();
			return value;
		}
	}

	public void put(int value) {
		synchronized (array) {
			while (pointer == array.length) {
				try {
					array.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			array[pointer++] = value;
			array.notify();
		}
	}
}
