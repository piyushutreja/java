package com.ankit.question3;

import java.util.ArrayList;
import java.util.List;

public class ListExample {

	public static void main(String[] args) throws InterruptedException {
		List<Integer> list = new ArrayList<Integer>();

		Thread t1 = new Thread(new Producer(list, 10));
		Thread t2 = new Thread(new Consumer(list));
		t1.start();
		t2.start();

	}
}

class Consumer implements Runnable {
	List<Integer> queue = null;

	public Consumer(List<Integer> queue) {
		this.queue = queue;
	}

	@Override
	public void run() {
		while (true) {
			synchronized (queue) {
				while (queue.isEmpty()) {
					try {
						queue.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				System.out.println("Consume : " + queue.remove(queue.size() - 1));
				queue.notify();
			}

		}

	}
}

class Producer implements Runnable {
	List<Integer> queue = null;
	int size;

	public Producer(List<Integer> queue, int size) {
		this.queue = queue;
		this.size = size;
	}

	@Override
	public void run() {
		for (int i = 0;; i++) {
			synchronized (queue) {
				while (queue.size() == size) {
					try {
						queue.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				queue.add(i);
				System.out.println("Produce :" + i);
				queue.notify();
			}
		}

	}
}