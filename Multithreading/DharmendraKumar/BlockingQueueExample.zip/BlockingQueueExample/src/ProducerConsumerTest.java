import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;


public class ProducerConsumerTest {
	public static void main(String[] args) throws InterruptedException {
		BlockingQueue<String> queue = new ArrayBlockingQueue<>(5);
		Producer p = new Producer(queue);
		Consumer q = new Consumer(queue);
		new Thread(p).start();
		new Thread(q).start();
		Thread.sleep(4000);
	}
}
