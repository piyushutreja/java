import java.util.concurrent.BlockingQueue;


public class Producer implements Runnable{
	BlockingQueue<String> queue;
	public Producer(BlockingQueue<String> queue) {
		this.queue = queue;
	}

	@Override
	public void run() {
			try {
				for(int i =0 ; i<6;i++){
					System.out.println("Pushing String"+i);
					queue.put("String"+i);
				}
				System.out.println("After 6 interations");
				for(int i =5 ; i<10;i++){
					System.out.println("Pushing String"+i);
					queue.put("String"+i);
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
