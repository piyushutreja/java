import java.util.List;

public class Consumer implements Runnable {
	List<String> stringList;
	public Consumer(List<String> stringList) {
		this.stringList = stringList;
	}

	@Override
	public void run() {
		while (true) {
			synchronized (stringList) {
				while(stringList.isEmpty()){
					try {
						System.out
						.println("List is empty. Waiting for Producer to put."+Thread.currentThread().getName());
						stringList.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				System.out.println("Pulling " + stringList.remove(0));
				stringList.notify();
			}
			
		}
	}
}
