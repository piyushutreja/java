import java.util.List;

public class Producer implements Runnable {
	List<String> stringList;

	public Producer(List<String> stringList) {
		this.stringList = stringList;
	}

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			synchronized (stringList) {
				while (stringList.size() >= 10) {
					try {
						System.out
								.println("List is full. Going to wait to get consumed.");
						stringList.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				System.out.println(Thread.currentThread().getName() + " Pushing String" + i);
				stringList
						.add(Thread.currentThread().getName() + " String" + i);
				stringList.notify();
			}
		}
	}
}
