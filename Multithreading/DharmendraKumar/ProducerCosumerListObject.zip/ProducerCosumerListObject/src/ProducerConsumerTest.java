import java.util.ArrayList;
import java.util.List;



public class ProducerConsumerTest {
	public static void main(String[] args) {
		List<String> stringList = new ArrayList<String>(10);
		Producer p = new Producer(stringList);
		Consumer q = new Consumer(stringList);
		
		new Thread(p).start();
		new Thread(q).start();
		new Thread(p).start();
		new Thread(q).start();
	}
}
