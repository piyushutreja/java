

public class ProducerConsumerTest {
	public static void main(String[] args) throws InterruptedException {
		MyList<String> customList = new MyList<String>(10);
		Producer p = new Producer(customList);
		Consumer q = new Consumer(customList);
		
		new Thread(p).start();
		new Thread(q).start();
		new Thread(p).start();
		new Thread(q).start();
	}
}
