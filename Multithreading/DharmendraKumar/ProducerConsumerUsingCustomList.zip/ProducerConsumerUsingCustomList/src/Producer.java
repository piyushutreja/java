public class Producer implements Runnable {
	MyList<String> customList;

	public Producer(MyList<String> customList) {
		this.customList = customList;
	}

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println("Pushing" + Thread.currentThread().getName()
					+ " String" + i);
			customList.put(Thread.currentThread().getName() + " String" + i);
		}
	}
}
