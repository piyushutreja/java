public class Consumer implements Runnable {
	MyList<String> customList;

	public Consumer(MyList<String> customList) {
		this.customList = customList;
	}

	@Override
	public void run() {
		while (true) {
			System.out.println("Pulling " + customList.get(0));
		}
	}
}
