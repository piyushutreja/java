package com.sapient.multithreading.ProdConsumerUsingCustomQueue;

import java.util.ArrayList;
import java.util.List;

public class ProducerConsumer {

	public static void main(String[] args) {
		CustomQueue<Integer> blockingQueue = new CustomQueue<Integer>(10);
		new Consumer(blockingQueue).start();
		new Producer(blockingQueue).start();

	}

}


 class CustomQueue<E> {

	  private List<E> list ;
	  private int  size = 10;

	  public CustomQueue(int limit){
	    this.size = limit;
	    list = new ArrayList<E>(limit);
	  }


	  public synchronized void put(E item)
	  throws InterruptedException  {
	    while(this.list.size() == this.size) {
	      wait();
	    }
	    if(this.list.size() == 0) {
	      notifyAll();
	    }
	    this.list.add(item);
	  }


	  public synchronized E take()
	  throws InterruptedException{
	    while(this.list.size() == 0){
	      wait();
	    }
	    if(this.list.size() == this.size){
	      notifyAll();
	    }

	    return this.list.remove(0);
	  }

	}
	 


class Consumer extends Thread {
	CustomQueue<Integer> blockingQueue;

	Consumer(CustomQueue<Integer> blockingQueue) {
		this.blockingQueue = blockingQueue;
	}

	public void run() {
		while (true) {

			try {
				Thread.sleep(500);
				int output = blockingQueue.take();
				System.out.println("Thread " + Thread.currentThread() + " consumes " + output);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

class Producer extends Thread {
	CustomQueue<Integer> blockingQueue;

	Producer(CustomQueue<Integer> blockingQueue) {
		this.blockingQueue = blockingQueue;
	}

	int i = 1;

	public void run() {

		while (true) {

			try {
				System.out.println("Thread " + Thread.currentThread() + " produces " + i);
				blockingQueue.put(i);
				i++;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
