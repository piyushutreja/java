package com.sapient.multithreading.ProdConsumerUsingThreadSafe;

import java.util.LinkedList;
import java.util.List;

class Buffer{
	List<Integer> list= new LinkedList<Integer>();
	volatile boolean available=false;
	
	public synchronized void put(int x){
		while(available){
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Thread "+Thread.currentThread()+" producing "+x);
		list.add(x);
		available=true;
		notifyAll();
		
	}
	public synchronized int get(){
		while(!available){
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		int item=list.remove(0);
		System.out.println("Thread "+Thread.currentThread()+" consuming "+item);
		available=false;
		notifyAll();
		return item;
		
	}
}
class Producer1 extends Thread{
	Buffer b;
	Producer1(Buffer b){
		this.b=b;
		
	}
	public void run(){
		for(int i=0;i<10;i++){
			b.put(i);
		}
	}
	
}
class Consumer1 extends Thread{
	Buffer b;
	Consumer1(Buffer b){
		this.b=b;
		
	}
	public void run(){
		for(int i=0;i<10;i++){
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println(b.get());
			b.get();
		}
	}
}
public class ProducerConsumer {
	public static void main(String args[]){
		Buffer b=new Buffer();
		Producer1 p=new Producer1(b);
		Consumer1 c=new Consumer1(b);
		p.start();
		c.start();
	}
}
