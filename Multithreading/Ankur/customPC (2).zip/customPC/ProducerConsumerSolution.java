package pc.customPC;


public class ProducerConsumerSolution {
	  public static void main(String args[]) throws InterruptedException {
		  CustomArrayList<Integer> sharedQueue = new CustomArrayList<>(4);
	        Thread prodThread = new Thread(new Producer(sharedQueue), "Producer");
	        Thread consThread = new Thread(new Consumer(sharedQueue), "Consumer");
	        prodThread.start();
	        consThread.start();
	       // prodThread1.start();
	        //consThread1.start();
	    }
   }
