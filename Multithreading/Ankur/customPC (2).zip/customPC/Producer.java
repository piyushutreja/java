package pc.customPC;




public class Producer implements Runnable {
   public CustomArrayList<Integer> list;
   public Producer(CustomArrayList<Integer> list){
	   System.out.println("Producer invoked");
	   this.list =list;
   }
	@Override
	public void run() {
for(int i =1;i<5;i++){
	System.out.println("Produced: "+i);
		try {
			list.put(i);
			//TimeUnit.SECONDS.sleep(1);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
}
}
