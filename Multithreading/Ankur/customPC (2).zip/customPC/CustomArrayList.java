package pc.customPC;



public class CustomArrayList<T> {
 
	  private T[] values;
	  private int size;
	  private int limit;
	  public CustomArrayList(int limit){
		  values = (T[]) new Object[10];
		  this.limit=limit;
	  }
	  public synchronized T take(int index) throws InterruptedException{
		  T returnValue;
		  while(size==0){
			  synchronized (this) {
			  	     this.wait();
			         }		
			  		}
		  synchronized (this) {
			  notifyAll();
			  returnValue = remove(index);
		  }
		   return returnValue;
	    }
	  public synchronized void put(T obj) throws InterruptedException{
	        while(size==limit){
	    		synchronized (this) {
	    				this.wait();
	    		}
	    	}
	    	synchronized (this){
	    		values[size++] = obj;
	    		  this.notifyAll();
	    	}
	    }
	  public int size(){
	        return size;
	    }
	  public T remove(int index) {
		  if(index < this.values.length){
	       T oldValue = this.values[index];
	        int numMoved = size - index - 1;
	        if (numMoved > 0)
	            System.arraycopy(values, index+1, values, index,
	                             numMoved);
	        values[--size] = null; // clear to let GC do its work

	        return oldValue;
		  }else {
	            throw new ArrayIndexOutOfBoundsException();
	        }
	    }
}
