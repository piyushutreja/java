package pc.customPC;

import java.util.concurrent.TimeUnit;


public class Consumer implements Runnable{
   public CustomArrayList<Integer> list;
   public Consumer(CustomArrayList<Integer> list) {
     this.list =list;
      }
	@Override
	public void run() {
	//	System.out.println("consumed running");
			try {
				for(int i=0;i<list.size();i++){
				System.out.println("Consumed : "+list.take(i));
				//TimeUnit.SECONDS.sleep(1);
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
}
}