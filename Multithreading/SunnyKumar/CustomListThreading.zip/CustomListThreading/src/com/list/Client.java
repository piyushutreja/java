package com.list;

public class Client {

	public static void main(String[] args) {
		
		CustomArrayList list=new CustomArrayList(1);
		
		Thread t1=new Thread(new Producer(list),"Producer Thread");
		Thread t2=new Thread(new Consumer(list), "Consumer Thread");
		t1.start();
		
        t2.start();
        
	}

}
