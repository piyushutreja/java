package com.list;

public class Producer implements Runnable{
	
	private CustomArrayList  customList;
	
	public Producer(CustomArrayList  customList) {
		
		this.customList=customList;
		
	}

	@Override
	public void run() {
		
		for(int i=0;i<=5;i++){
			try {
				customList.add(i);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
		
		
	}
	
	

}
