package com.list;

public class CustomArrayList {
	

	private Integer[] elements;
	private int actSize = 0;

	private int size = 0;

	public CustomArrayList(int size) {
		elements = new Integer[size];
		this.size = size;
	}

	public Object get() throws InterruptedException {

		while (actSize == 0) {

			synchronized (this) {
				System.out.println("Wait is called by inside get method : "+Thread.currentThread().getName());
				this.wait();
                
			}

		}

		synchronized (this) {
			Integer element = elements[0];
			elements[0] = null;
			--actSize;
			System.out.println("notify is called by inside get method : "+Thread.currentThread().getName());
			this.notifyAll();
			return element;
		}
		
	}

	public void add(Integer element) throws InterruptedException {

		while (actSize == size) {
			synchronized (this) {
				System.out.println("wait is called by inside add method : "+Thread.currentThread().getName());
				this.wait();

			}

		}

		synchronized (this) {
			elements[actSize] = element;
			++actSize;
			System.out.println("notify is called by inside add method : "+Thread.currentThread().getName());
			this.notifyAll();
			System.out.println("actSize: "+ actSize);
		}

	}

}
