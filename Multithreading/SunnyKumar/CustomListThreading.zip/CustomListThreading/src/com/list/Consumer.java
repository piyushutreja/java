package com.list;

public class Consumer implements Runnable{
	
private CustomArrayList  customList;
	
	public Consumer(CustomArrayList  customList) {
		
		this.customList=customList;
		
	}

	@Override
	public void run() {
		while(true){
            try {
                System.out.println("value in the list :"+customList.get());
            } catch (InterruptedException ex) {
            }
        }

		
	}

}
