package com.list;

import java.util.List;

public class Producer implements Runnable {

	private List<Integer> list;

	private int size;

	public Producer(List<Integer> list, int size) {

		this.list = list;
		this.size = size;

	}

	@Override
	public void run() {

		for (int i = 0; i <= 5; i++) {
			try {
				while (list.size() == size) {

					synchronized (list) {
						list.wait();
					}

				}
				synchronized (list) {

					list.add(i);
					System.out.println("value in list : " + list.get(i));
					list.notifyAll();
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}

	}

}
