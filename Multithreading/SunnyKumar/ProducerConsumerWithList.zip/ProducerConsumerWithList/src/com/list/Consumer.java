package com.list;

import java.util.List;

public class Consumer implements Runnable {

	private List<Integer> list;

	public Consumer(List<Integer> list) {

		this.list = list;

	}

	@Override
	public void run() {

		while (true) {
			try {

				while (list.isEmpty()) {
					synchronized (list) {
						list.wait();
					}

				}

				synchronized (list) {
					System.out.println("value in the list :" + list.remove(0));
					list.notifyAll();
				}

			} catch (InterruptedException ex) {
			}
			
			
		}

	}

}
