package com.blocking;

import java.util.concurrent.BlockingQueue;

public class Consumer implements Runnable{
	
private BlockingQueue<Integer>  blokingQueue;
	
	public Consumer(BlockingQueue<Integer>  blokingQueue) {
		
		this.blokingQueue=blokingQueue;
		
	}

	@Override
	public void run() {
		while(true){
            try {
                System.out.println(blokingQueue.take());
            } catch (InterruptedException ex) {
            }
        }

		
	}

}
