package com.blocking;

import java.util.concurrent.BlockingQueue;

public class Producer implements Runnable{
	
	private BlockingQueue<Integer>  blokingQueue;
	
	public Producer(BlockingQueue<Integer>  blokingQueue) {
		
		this.blokingQueue=blokingQueue;
		
	}

	@Override
	public void run() {
		
		for(int i=0;i<5;i++){
			try {
				blokingQueue.put(i);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
	}
	
	

}
