package com.blocking;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Client {

	public static void main(String[] args) {
		
		BlockingQueue<Integer> blockinQueue=new ArrayBlockingQueue<Integer>(6);
		
		Thread t1=new Thread(new Producer(blockinQueue));
		Thread t2=new Thread(new Consumer(blockinQueue));
		t1.start();
		
        t2.start();
        
	}

}
