package com.sapient.customqueue;

public class Producer extends Thread {
	MyQueue<Integer> blockingQueue;

	Producer(MyQueue<Integer> blockingQueue) {
		this.blockingQueue = blockingQueue;
	}

	int x = 1;

	public void run() {

		while (true) {

			try {
				Thread.sleep(100);
				System.out.println(Thread.currentThread() + " produced " + x);
				blockingQueue.put(x);
				x++;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}