package com.sapient.customqueue;

public class Consumer extends Thread {
	MyQueue<Integer> blockingQueue;

	Consumer(MyQueue<Integer> blockingQueue) {
		this.blockingQueue = blockingQueue;
	}

	public void run() {
		while (true) {

			try {
				Thread.sleep(100);
				int output = blockingQueue.take();
				System.out.println(Thread.currentThread() + " consumed "
						+ output);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}