package com.sapient.customqueue;

import java.util.ArrayList;
import java.util.List;

public class MyQueue<T> {

	private List<T> list;
	private int size = 0;

	public MyQueue(int limit) {
		this.size = limit;
		list = new ArrayList<T>(limit);
	}

	public synchronized void put(T value) throws InterruptedException {
		while (list.size() == this.size) {
			wait();
		}
		if (this.list.size() == 0) {
			notifyAll();
		}
		this.list.add(value);
	}

	public synchronized T take() throws InterruptedException {
		while (list.size() == 0) {
			wait();
		}
		if (this.list.size() == this.size) {
			notifyAll();
		}

		return list.remove(0);
	}

}