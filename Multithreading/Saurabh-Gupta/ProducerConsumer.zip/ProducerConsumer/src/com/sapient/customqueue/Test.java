package com.sapient.customqueue;

public class Test {

	public static void main(String[] args) {
		MyQueue<Integer> blockingQueue = new MyQueue<Integer>(10);
		Thread consumerQueue = new Consumer(blockingQueue);
		Thread producerQueue = new Producer(blockingQueue);
		producerQueue.setName("Producer");
		producerQueue.setName("Consumer");
		consumerQueue.start();
		producerQueue.start();

	}

}


