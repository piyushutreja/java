package com.sapient.blockingQ;

import java.util.concurrent.BlockingQueue;

public class Consumer extends Thread {
	BlockingQueue<Integer> blockingQueue;

	public Consumer(BlockingQueue<Integer> blockingQueue) {
		this.blockingQueue = blockingQueue;
	}

	public void run() {
		while (true) {

			try {

				int output = blockingQueue.take();
				System.out.println("Thread " + Thread.currentThread()
						+ " consumes " + output);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}