package com.sapient.blockingQ;

import java.util.concurrent.BlockingQueue;

public class Producer extends Thread {
	BlockingQueue<Integer> blockingQueue;

	public Producer(BlockingQueue<Integer> blockingQueue) {
		this.blockingQueue = blockingQueue;
	}

	int i = 1;

	public void run() {
		while (true) {

			try {

				System.out.println("Thread " + Thread.currentThread()
						+ " produces " + i);
				blockingQueue.put(i);
				i++;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}