package com.sapient.blockingQ;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Test {

	public static void main(String[] args) {
		BlockingQueue<Integer> blockingQueue = new ArrayBlockingQueue<Integer>(
				10);
		Thread consumerThread = new Consumer(blockingQueue);
		Thread producerThread = new Producer(blockingQueue);
		consumerThread.setName("Consumer");
		producerThread.setName("Producer");
		consumerThread.start();
		producerThread.start();

	}

}


