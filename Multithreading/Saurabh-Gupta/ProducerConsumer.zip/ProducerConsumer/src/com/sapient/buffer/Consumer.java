package com.sapient.buffer;
public class Consumer extends Thread {
	Buffer b;

	Consumer(Buffer b) {
		this.b = b;

	}

	public void run() {
		while(true) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// System.out.println(b.get());
			b.get();
		}
	}
}