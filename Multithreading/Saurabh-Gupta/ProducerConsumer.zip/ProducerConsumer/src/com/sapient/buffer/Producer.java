package com.sapient.buffer;
public class Producer extends Thread {
	Buffer b;

	Producer(Buffer b) {
		this.b = b;

	}

	public void run() {
		int i=1;
		while(true) {
			b.put(i);
			i++;
		}
	}

}