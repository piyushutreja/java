package com.sapient.buffer;

import java.util.LinkedList;
import java.util.List;

public class Buffer {
	List<Integer> list = new LinkedList<Integer>();
	volatile boolean available = false;

	public synchronized void put(int x) {
		while (available) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println(Thread.currentThread() + " produced "
				+ x);
		list.add(x);
		available = true;
		notifyAll();

	}

	public synchronized int get() {
		while (!available) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		int item = list.remove(0);
		System.out.println(Thread.currentThread() + " consumed "
				+ item);
		available = false;
		notifyAll();
		return item;

	}
}