package com.example;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Blocking {

	public static void main(String[] args) {
		BlockingQueue<Integer> bq=new ArrayBlockingQueue<Integer>(10);

		//1.	Implement Consumer and Producer algorithm, using BlockingQueue implementations.
		//Start
		Producer prod=new Producer(bq);
		Consumer cons=new Consumer(bq);
		
		prod.start();
		cons.start();
		
		//End

	}

}

class Producer extends Thread{
	
	private final BlockingQueue<Integer> bq;
	
	public Producer(BlockingQueue<Integer> bq){
		this.bq=bq;
	}
	
	@Override
	public void run() {
		for(int i=0;i<10;i++){
			try {
				bq.put(i);
				System.out.println("Produced: "+i);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

class Consumer extends Thread{
	private final BlockingQueue<Integer> bq;
	
	public Consumer(BlockingQueue<Integer> bq){
		this.bq=bq;
	}
	
	@Override
	public void run() {
		for(int i=0;i<10;i++){
			try {
				System.out.println("Consumed: "+bq.take());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}
	
