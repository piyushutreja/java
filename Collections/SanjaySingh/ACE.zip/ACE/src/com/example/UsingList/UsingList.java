package com.example.UsingList;

import java.util.concurrent.CopyOnWriteArrayList;

public class UsingList {

	public static void main(String[] args) {
		CopyOnWriteArrayList aList=new CopyOnWriteArrayList();

		//3.	Implement Consumer and Producer algorithm, over a List object. Ensure that read/write to this list is thread-safe
		//Start
		ProducerForList prodList=new ProducerForList(aList);
		ConsumerForList consList=new ConsumerForList(aList);
		
		prodList.start();
		consList.start();
		//End
	}

}

class ProducerForList extends Thread{
	private final CopyOnWriteArrayList list;
	
	public ProducerForList(CopyOnWriteArrayList list){
		this.list=list;
	}
	
	@Override
	public void run() {
		for(int i=0;i<10;i++){
			try {
				list.add(i);
				System.out.println("Produced: "+i);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}

class ConsumerForList extends Thread{
	private final CopyOnWriteArrayList list;
	
	public ConsumerForList(CopyOnWriteArrayList list){
		this.list=list;
	}
	
	@Override
	public void run() {
		for(int i=0;i<10;i++){
			try {
				if(list.size()>=i){
					System.out.println("Consumed: "+list.get(i));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
}