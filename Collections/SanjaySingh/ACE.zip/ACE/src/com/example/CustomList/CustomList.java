package com.example.CustomList;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class CustomList {

	public static void main(String[] args) {
		MyList list=new MyList(10);
		
		//2.	Implement Consumer and Producer algorithm, ensuring thread-safe read/write over elements of a CustomList (your customized class, having get() and put())
		//Start
		ProducerForMyList prodMyList=new ProducerForMyList(list);
		ConsumerForMyList consMyList=new ConsumerForMyList(list);
		
		prodMyList.start();
		consMyList.start();
		
		//End
		
	}

}


class MyList{
	final ReentrantLock lock;
	boolean flag=false;
	final Object[] items;
    int takeIndex;
    int putIndex;
    int count;
    private final Condition notEmpty;
    private final Condition notFull;
	
    public MyList(int capacity) {
        this(capacity, false);
    }
    
    public MyList(int capacity, boolean fair) {
        if (capacity <= 0)
            throw new IllegalArgumentException();
        this.items = new Object[capacity];
        lock = new ReentrantLock(fair);
        notEmpty = lock.newCondition();
        notFull =  lock.newCondition();
    }
    
	public boolean put(Object e)  throws InterruptedException  {
        checkNotNull(e);
        final ReentrantLock lock = this.lock;
        lock.lockInterruptibly();
        try {
            while (count == items.length)
                notFull.await();
            add(e);
        } finally {
            lock.unlock();
        }
	    return flag;
	}

	public Object get(int index) throws InterruptedException {
	 final ReentrantLock lock = this.lock;
        lock.lockInterruptibly();
        try {
            while (count == 0)
                notEmpty.await();
            return remove();
        } finally {
            lock.unlock();
        }
	}
	
	private static void checkNotNull(Object v) {
        if (v == null)
            throw new NullPointerException();
    }
	
    private void add(Object x) {
        final Object[] items = this.items;
        items[putIndex] = x;
        if (++putIndex == items.length)
            putIndex = 0;
        count++;
        notEmpty.signal();
    }
    
    private Object remove() {
        final Object[] items = this.items;
        Object x = (Object) items[takeIndex];
        items[takeIndex] = null;
        if (++takeIndex == items.length)
            takeIndex = 0;
        count--;
        notFull.signal();
        return x;
    }
}

class ProducerForMyList extends Thread{
	private final MyList list;
	
	public ProducerForMyList(MyList list){
		this.list=list;
	}
	
	@Override
	public void run() {
		for(int i=0;i<10;i++){
			try {
				list.put(i);
				System.out.println("Produced: "+i);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}

class ConsumerForMyList extends Thread{
	private final MyList list;
	
	public ConsumerForMyList(MyList list){
		this.list=list;
	}
	
	@Override
	public void run() {
		for(int i=0;i<10;i++){
			try {
				System.out.println("Consumed: "+list.get(i));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
}

