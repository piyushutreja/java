package com.example.threads;

import java.util.ArrayList;
import java.util.List;

public class ThreadsExample {

	public static void main(String[] args) {
		Thread t1=new Thread(new MyRunnable());
		Thread t2 =new Thread(new MyRunnable());
		
		t1.start();
		t2.start();
		
//		t1.interrupt();
		t2.interrupt();
		
	}

}

class MyRunnable implements Runnable{

	@Override
	public void run() {
		
	}
	
}

class MyClass{
	private List list=new ArrayList<>();
	boolean flag=false;
	void readList(){
		synchronized (this) {
			while(flag){
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
