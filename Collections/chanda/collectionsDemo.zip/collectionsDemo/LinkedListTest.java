package training.sape.collectionsDemo;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class LinkedListTest {
	List<String> list;
	
	public void inputNames(){
		list=new LinkedList<String>();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name of your five friends");
		for(int i=0;i<5;i++){
			list.add(sc.next());
		}
	}
	public void showNames(){
		Iterator<String> it=list.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
	}
	public void deleteName(int i){
		list.remove(i);
		System.out.println("Item 3 deleted");
		System.out.println("New list is as....");
		showNames();
	}
	public static void main(String[] args) {
		LinkedListTest linkedListTest=new LinkedListTest();
		linkedListTest.inputNames();
		linkedListTest.showNames();
		linkedListTest.deleteName(2);

	}

}
