package training.sape.collectionsDemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo{
	Set<Integer> set;
	int d;
	public void genNumber(){
		set=new HashSet<Integer>();
		while(set.size()<10){
			d=(int)( 1+(Math.random()*10));
			//System.out.println(d);
			set.add(d);
		
		}
		System.out.println(set);
		System.out.println("size="+set.size());
	}
	public void sortNumber(){
		List list=new ArrayList(set);
		Collections.sort(list);
		System.out.println(list);
	}
	public void sortedNumber(){
		Set set=new TreeSet();
		while(set.size()<10){
			d=(int)( 1+(Math.random()*10));
			set.add(d);
	}
		System.out.println(set);
	}

	public static void main(String[] args) {
		SetDemo setDemo=new SetDemo();
		setDemo.genNumber();
		setDemo.sortNumber();
		setDemo.sortedNumber();

	}
}
