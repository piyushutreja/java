package training.sape.collectionsDemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Fruits {
	List<String> list;
	public void storeFruit(){
		list=new ArrayList<String>();
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter 5 fruits");
		for(int i=0;i<5;i++){
			list.add(sc.next());
		}
		
	}
	public void showFruits()
	{
		Iterator<String> it=list.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
	}
	public void sortFruits(){
		Collections.sort(list);
	}
	public void searchFruits(String fruit){
		if(list.contains(fruit)){
		System.out.println("Item found");
	}
		else{
			System.out.println("Not found");
		}
	}

	public static void main(String[] args) {
		Fruits fruits=new Fruits();
		fruits.storeFruit();
		fruits.showFruits();
		fruits.searchFruits("apple");

	}

}
