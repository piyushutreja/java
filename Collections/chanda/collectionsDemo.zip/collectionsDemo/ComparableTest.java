package training.sape.collectionsDemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

class Employee implements Comparable<Employee>{
	 int id;
	 String name;
	 double salary;
	public Employee(int id,String name,double salary){
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	@Override
	public int compareTo(Employee o) {
		if(id<o.id){
			return -1;
		}
		else if(id==o.id){
			return 0;
		}
		else{
			return 1;
		}
		
	}
}

public class ComparableTest {

	public static void main(String[] args) {
		List<Employee> set=new ArrayList<Employee>();
		Employee e1=new Employee(10, "aaa", 230000);
		Employee e2=new Employee(1, "Rekha", 230000);
		Employee e3=new Employee(12, "Neha", 230000);
		set.add(e3);
		set.add(e2);
		set.add(e1);
		Collections.sort(set);
		for(Employee e:set){
			System.out.println(e.id+""+e.name);
			
		}

	}

}
