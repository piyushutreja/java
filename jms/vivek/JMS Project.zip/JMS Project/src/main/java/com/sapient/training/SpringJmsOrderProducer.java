package com.sapient.training;

import org.springframework.jms.core.JmsTemplate;

public class SpringJmsOrderProducer {


	private JmsTemplate jmsTemplate;

	public JmsTemplate getJmsTemplate() {
		return jmsTemplate;
	}

	public void setJmsTemplate(JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}

	public void sendMessage(final Order order) {
		getJmsTemplate().convertAndSend(order);
	}
}
