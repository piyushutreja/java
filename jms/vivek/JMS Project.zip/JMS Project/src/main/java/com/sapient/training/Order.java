package com.sapient.training;

public class Order {
	
	private long orderId;
	private int orderQuantity;
	private String orderStatus;
	private int price;
	
	
	
	public Order(long orderId, int orderQuantity, String orderStatus,int price) {
		if(price<=0)
		{
			throw new IllegalArgumentException("Price can not be zero");
		}
		this.orderId = orderId;
		this.orderQuantity = orderQuantity;
		this.orderStatus = orderStatus;
		this.price=price;
	}
	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
	public int getOrderQuantity() {
		return orderQuantity;
	}
	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderQuantity=" + orderQuantity + ", orderStatus=" + orderStatus
				+ ", price=" + price + "]";
	}
	
	
	

}
