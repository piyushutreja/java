
public enum Status {
	NEW,
	CANCELLED,
	REJECTED,
	PROCESSED,
	UNKNOWN;
	
}
