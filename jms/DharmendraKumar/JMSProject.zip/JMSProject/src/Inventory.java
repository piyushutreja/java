
public class Inventory {
	public static final Integer MAX_QUNATITY = 100;
}
