package com.jms;

import java.io.Serializable;

public class Order implements Serializable {
	private int orderId;
	private int amount;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	 public String toString() {
		return "orderId= "+orderId+"   amount= "+amount ;
		 
	 }
}
