package com.jms.utils;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

import com.jms.Order;

public class OrderMessageConverter implements MessageConverter {

	@Override
	public Object fromMessage(Message message) throws JMSException,
			MessageConversionException {
		MapMessage mapmessage =(MapMessage)message;
		Order order = new Order();
		order.setAmount(mapmessage.getInt("amount"));
		order.setOrderId(mapmessage.getInt("orderId"));
		return order;
	}

	@Override
	public Message toMessage(Object object, Session session) throws JMSException,
			MessageConversionException {
		Order order = (Order) object;
		MapMessage message = session.createMapMessage();
		message.setInt("orderId", order.getOrderId());
		message.setInt("amount", order.getAmount());
		return message;
	}

}
