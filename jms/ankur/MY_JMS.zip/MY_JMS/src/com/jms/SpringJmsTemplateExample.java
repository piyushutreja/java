package com.jms;


import java.net.URISyntaxException;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringJmsTemplateExample {
	public static void main(String[] args) throws URISyntaxException, Exception {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		try {
			MySender orderProducer = (MySender) context
					.getBean("jmsProducer");
			Order order = new Order();
			order.setAmount(100);
			order.setOrderId(1);
			orderProducer.sendMessage(order);

			MyConsumer orderConsumer = (MyConsumer) context
					.getBean("jmsConsumer");
			Order retrunorder = orderConsumer.receiveMessage();
			MySender orderExecProducer = (MySender) context
					.getBean("jmsExecProducer");
			orderExecProducer.sendMessage(retrunorder);
			MyConsumer orderexecConsumer = (MyConsumer) context
					.getBean("jmsExecConsumer");
			orderexecConsumer.receiveMessage();
		} finally {
			context.close();
		}
	}
}