package com.jms;

import java.util.concurrent.Callable;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.activemq.ActiveMQConnectionFactory;

import com.jms.exception.PriceValidationException;

public class Producer implements Callable<Boolean>{

	private String queueName;

	private Order order;

	public Producer(String queueName, Order order) {

		this.order = order;
		this.queueName = queueName;

	}

	private boolean sendMessage() throws PriceValidationException {
		
		boolean status=false;

		try {
			InitialContext context = new InitialContext();
			ActiveMQConnectionFactory factory = (ActiveMQConnectionFactory) context.lookup("connectionFactory");
			Connection connection = factory.createConnection();
			connection.start();

			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

			Queue queue = session.createQueue(queueName);

			MessageProducer producer = session.createProducer(queue);

			ObjectMessage message = session.createObjectMessage();

			boolean validate = validateOrder(order);

			if (!validate) {
				throw new PriceValidationException(order.toString() + " is not valid amount");
			}
			message.setObject(order);
			producer.send(message);
			status=true;
			context.close();
			connection.close();

		} catch (NamingException excep) {
			excep.printStackTrace();
		} catch (JMSException excep) {
			excep.printStackTrace();
		}
		
		return status;

	}

	private boolean validateOrder(Order order) {

		Double quantity = order.getQuantity();

		if (null == quantity || quantity.doubleValue() <= 0) {

			return false;
		} else {

			return true;
		}

	}

	
	@Override
	public Boolean call() throws PriceValidationException {
		
		return sendMessage();
	}

}
