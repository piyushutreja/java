package com.jms.client;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.jms.Order;
import com.jms.Producer;
import com.jms.Reciever;
import com.jms.exception.PriceValidationException;

public class MessagingClient {

	public static void main(String[] args) throws PriceValidationException {

		Order order = new Order();

		order.setQuantity(12.0);

		order.setStatus("Pending");

		ExecutorService executor = Executors.newFixedThreadPool(3);

		Callable<Boolean> firstProducer = new Producer("orderQueue", order);

		Future<Boolean> future1 = executor.submit(firstProducer);

		try {
			if (future1.get()) {

				Callable<Order> firstReciver = new Reciever("orderQueue");

				Future<Order> recivedFuture = executor.submit(firstReciver);

				Order recvOrder = recivedFuture.get();

				if (null != recvOrder) {
					Callable<Boolean> secondProducer = new Producer("executedOrderQueue", recvOrder);

					executor.submit(secondProducer);
					System.out.println(recvOrder.toString() + " is succsessfully processed");
				}
			}
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}

	}

}
