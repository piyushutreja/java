package com.jms.exception;

public class PriceValidationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public PriceValidationException(String message){
		
		super(message);
	}

}
