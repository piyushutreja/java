package com.jms;

import java.util.concurrent.Callable;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.activemq.ActiveMQConnectionFactory;

import com.jms.exception.PriceValidationException;

public class Reciever implements Callable<Order>{

	private String queueName;

	public Reciever(String queueName) {

		this.queueName = queueName;
	}

	public Order recieveMessage() throws PriceValidationException {

		Order order = null;

		try {
			InitialContext context = new InitialContext();
			ActiveMQConnectionFactory factory = (ActiveMQConnectionFactory) context.lookup("connectionFactory");
			factory.setTrustAllPackages(true);
			Connection connection = factory.createConnection();
			connection.start();

			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

			Queue queue = session.createQueue(queueName);

			MessageConsumer consumer = session.createConsumer(queue);

			Message message = consumer.receive();

			if (message instanceof ObjectMessage) {
				ObjectMessage objMessage = (ObjectMessage) message;

				order = (Order) objMessage.getObject();

				Double quantity = order.getQuantity();
				if (null != quantity && quantity <= 10) {

					throw new PriceValidationException("Quantity in order should be greater than 10");
				}

				order.setStatus("Processed");
			}

			context.close();
			connection.close();

		} catch (NamingException e) {
			e.printStackTrace();
		} catch (JMSException e) {
			e.printStackTrace();
		}

		return order;

	}

	@Override
	public Order call() throws Exception {
		return recieveMessage();
	}

}
